package com.capgemini.fms.dao;

import java.util.HashMap;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.exception.FeedbackException;

public interface CoordinatorDao {
	int addTrainingProgarm(TrainingProgram trainingProgram)
			throws FeedbackException;

	public HashMap<Integer, Course> getcourseNames();

	public HashMap<Integer, Employee> getFaculties();

	public void updateTraining(TrainingProgram trainingProgram)
			throws FeedbackException;

	public TrainingProgram getTrainingById(int trainingId);

	public void deleteTrainingProgarm(int trainingId)
			throws FeedbackException;

	public void addParticipant(String courseName, int employeeId)
			throws FeedbackException;

}