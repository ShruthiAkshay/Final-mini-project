package com.capgemini.fms.dao;

import java.util.HashMap;

import com.capgemini.fms.bean.FeedBack;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.exception.FeedbackException;

public interface ParticipantDAO {
HashMap<Integer, String> getTrainingListByParticipantID(int traineeId) throws FeedbackException;
TrainingProgram getTrainingDetails(int trainingId) throws FeedbackException;
void addFeedback(FeedBack feedback) throws FeedbackException;
}
