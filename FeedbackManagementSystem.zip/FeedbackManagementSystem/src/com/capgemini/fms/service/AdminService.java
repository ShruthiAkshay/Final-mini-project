package com.capgemini.fms.service;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.exception.FeedbackException;

public interface AdminService {
	public void addSkillSet(Faculty faculty) throws FeedbackException;

	public Employee getEmployeeById(int employeeId) throws FeedbackException ;
	
	public HashMap<Integer, Employee> getEmployees() throws FeedbackException ;

	public String getUser(int employeeId, String password) throws FeedbackException;
	
	public int addCourse(Course course) throws FeedbackException;
	
	public Map<Integer, Course> getCourses() throws FeedbackException;
	
	public void deleteCourse(int courseId) throws FeedbackException;
	
	public void updateCourse(Course course) throws FeedbackException;
}
