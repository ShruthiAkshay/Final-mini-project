package com.capgemini.fms.service;

import java.util.ArrayList;
import com.capgemini.fms.bean.ReportBean;
import com.capgemini.fms.exception.FeedbackException;

public interface ReportService {
	public ArrayList<ReportBean> getAllTrainingReport(int month)throws FeedbackException;

	public ArrayList<ReportBean> getFacultyReport(int facultyId,int month)
			throws FeedbackException ;
	public ArrayList<ReportBean> getDefaulterReport(int month)
			throws FeedbackException ;
	}
