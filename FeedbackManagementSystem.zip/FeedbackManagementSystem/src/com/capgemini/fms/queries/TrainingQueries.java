package com.capgemini.fms.queries;

public interface TrainingQueries {

	public String addTrainingProgram="INSERT INTO TRAINING_PROGRAM VALUES ( Training_Code.nextval,?,?,?,?)";
	public String getTrainingId="SELECT Training_Code.currval FROM DUAL";
	public String getCourseName="SELECT  Course_IDs,Course_Name,No_Of_Days from COURSE_MASTER";
	public String getCourseById="SELECT  Course_IDs,Course_Name,No_Of_Days from COURSE_MASTER WHERE Course_IDs=?";
	public String getFaculties="SELECT  Employee_ID  ,Employee_Name   from EMPLOYEE_MASTER where Employee_ID IN "
				+ "(SELECT FacultyId  from FACULTY_SKILL )";
	public String updateTraining="update TRAINING_PROGRAM set Course_IDs =?, FacultyId =?, StartDate =?, EndDate =? where Training_code =?";
	public String getTrainingByid="SELECT  Training_code ,Course_Ids ,FacultyId ,StartDate ,EndDate  from TRAINING_PROGRAM WHERE Training_code =?";
	public String deleteTraining="delete from  TRAINING_PROGRAM WHERE Training_Code =?";
	public String addParticipant="INSERT INTO TRAINING_ENROLLMENT VALUES (?,?)";
	public String getTrainingCodeCourse="SELECT Training_code from TRAINING_PROGRAM WHERE Course_IDs = (select Course_IDs from COURSE_MASTER where Course_Name =?)";

}
