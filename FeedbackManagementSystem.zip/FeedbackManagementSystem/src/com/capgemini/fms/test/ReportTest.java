package com.capgemini.fms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.fms.dao.ReportDao;
import com.capgemini.fms.dao.ReportDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class ReportTest {
ReportDao dao=new ReportDaoImpl();
ReportDaoImpl report= new ReportDaoImpl();
	@Test
	public void testGetAllTrainingReport() throws FeedbackException {
	assertNotNull(dao.getAllTrainingReport(2));
	}

	@Test
	public void testGetAverageReport() throws FeedbackException {
		assertNotNull(report.getAverageReport(101));
	}

	@Test
	public void testGetFacultyName() throws FeedbackException {
		assertEquals("Kavita",report.getFacultyName(102));
	}

	@Test
	public void testGetFacultyReport() throws FeedbackException {
		assertNotNull(dao.getFacultyReport(10000, 3));
	}

	

	@Test
	public void testGetDefaulterReport() throws FeedbackException {
		assertNotNull(report.getDefaulterReport(4));
	}

	@Test
	public void testGetReports() throws FeedbackException {
		assertNotNull(report.getReports(101));
	}

	@Test
	public void testGetParticipantName() throws FeedbackException {
		assertEquals("Nisank", report.getParticipantName(101, 13069));
	}

}
