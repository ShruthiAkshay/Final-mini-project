select * from EMPLOYEE_MASTER;

Insert into Employee_master values(10000,'Shazaan','shazaan','Participant');

Insert into Employee_master values(10001,'admin','admin','Admin');

Insert into Employee_master values(10002,'Nishank','nishank','Coordinator');

Insert into Employee_master values(10003,'Pallavi','pallavi','Participant');

Insert into Employee_master values(10004,'Prachi','prachi','Participant');

Insert into Employee_master values(10005,'Sanjivani','sanjivani','Participant');

Delete From EMPLOYEE_MASTER;

select * from COURSE_MASTER;

CREATE TABLE Faculty_Skill(FacultyId number(5),skillset varchar2(30),FOREIGN KEY(FacultyId) REFERENCES Employee_Master(Employee_Id));

CREATE TABLE Employee_master(Employee_Id number(5) PRIMARY KEY, Employee_Name varchar2(30), Password varchar2(30),
Role varchar2(30));

CREATE TABLE Course_Master(Course_Ids number(5), Course_Name varchar2(30), No_Of_Days number(5), PRIMARY KEY(Course_Ids));

CREATE TABLE Training_Program(Training_Code number(5) PRIMARY KEY,Course_Ids number(5),FacultyId number(5),startdate date,enddate date,
FOREIGN KEY(Course_Ids) REFERENCES Course_Master(Course_Ids),FOREIGN KEY(FacultyId) REFERENCES Faculty_Skill(FacultyId));

CREATE TABLE Feedback_Master(Training_Code number(5),Participant_Id number(5),fb_prs_comm number(1),fb_clrfy_dbts number(1),
fb_tm number(1),fb_hnd_out number(1),fb_hw_sw_ntwrk number(1),FOREIGN KEY(Training_Code) REFERENCES Training_Program(Training_Code),
FOREIGN KEY(Participant_Id) REFERENCES Employee_master(Employee_Id));

CREATE TABLE Training_Enrollment(Training_Code number(5),Participant_Id number(5),
FOREIGN KEY(Training_Code) REFERENCES Training_Program(Training_Code),
FOREIGN KEY(Participant_Id) REFERENCES Employee_master(Employee_Id));


CREATE SEQUENCE Course_Ids 
	INCREMENT BY 1
	START WITH 1000
	MAXVALUE 10000
	NOCYCLE;
CREATE SEQUENCE Training_Code 
	INCREMENT BY 1
	START WITH 1
	MAXVALUE 10000
	NOCYCLE;
	
	Drop Sequence Cousre_ids;
	
	
	
Select * from Training_Enrollment;

Insert into TRAINING_ENROLLMENT values(1005,10000);

Select * from FEEDBACK_MASTER;